import Vue from 'vue';
import Vuex from 'vuex';
import {api} from '../api/api';

Vue.use(Vuex);

const realtorsModule = {
    namespaced: true,
    state: () => ({
        items: [],
        addNewRealtorFormActive: false
    }),
    getters: {
        realtorsItems: state => {
            return state.items
        }
    },
    // Actions
    mutations: {
        setRealtors(state, items) {

            console.log(items);
            state.items = items;
        },
        updateRealtors(state) {

           // state.items.forEach(i => i.firstName = i.firstName + "1")
        },
        saveRealtorSuccess(state, item) {
            console.log(item)
            let itemIndex = -1;
            state.items.forEach((i, index) => {
                if (i.id === item.id) {
                    debugger;
                    itemIndex = index
                    i.registrationDate = item.registrationDate;
                }


            });
            //Vue.set(state.items, itemIndex, {...oldItem, ...item})
           // oldItem.firstName = "blabalbalba";
        },
        createRealtorSuccess(state, item) {
            console.log('createRealtorSuccess')
        },
        getAddNewRealtorFormActive() {
            this.state.addNewRealtorFormActive = !this.state.addNewRealtorFormActive;

        }
    },
    // Thunks
    actions: {
        async updateRealtors(context) {
            setInterval(() => {
                context.commit('updateRealtors')
            }, 3000)
        },
        async fetchRealtors(context) {
            const snapShot = await api.getRealtors();
            const arrayDoc = snapShot.docs.map((doc) => ({
                ...doc.data(), id: doc.id
            }));

            context.commit('setRealtors', arrayDoc)
        },
        async saveRealtor(context, data) {
            await api.updateRealtors(data);
            context.commit('saveRealtorSuccess', data);
        },
        async createRealtor(context, data) {
            // maxId + 1(как documentPath(подробности в файле api))
            // const guid = v1(); // Создали в api-шке
            const maxId = this.state.items.reduce((acc, item) => {
                if (acc < item.id) {
                    return item.id
                } else {
                    return acc
                }
            }, 1);

            context.commit('saveRealtorSuccess', data)
        },

    },
};

export default new Vuex.Store({
    state: () => ({}),
    mutations: {},
    actions: {},
    getters: {},
    modules: {
        realtors: realtorsModule
    }
})


