<template>
    <v-card
            class="mx-auto overflow-hidden"
            height="400"
    >
        <v-app-bar
                color="primary"
                dark
        >
            <v-app-bar-nav-icon @click="drawer = true"></v-app-bar-nav-icon>

            <v-toolbar-title>Realtors</v-toolbar-title>

            <v-spacer></v-spacer>
            <v-btn outlined to="/create">Новый риэлтор</v-btn>
            <v-spacer></v-spacer>
            <v-btn outlined to="/realtors-table">Список риэлторов</v-btn>
            <v-spacer></v-spacer>
            <v-text-field
                    v-model="search"
                    append-icon="mdi-magnify"
                    label="Поиск по сотрудникам"
                    single-line
                    hide-details
            ></v-text-field>
            <v-btn outlined class="searchButton">Найти</v-btn>

        </v-app-bar>

        <v-navigation-drawer
                v-model="drawer"
                absolute
                temporary
        >
            <v-list
                    nav
                    dense
            >
                <v-list-item-group
                        v-model="group"
                        active-class="deep-purple--text text--accent-4"
                >
                    <v-list-item to="/">
                        <v-list-item-icon>
                            <v-icon>mdi-home</v-icon>
                        </v-list-item-icon>
                        <v-list-item-title>Главная</v-list-item-title>
                    </v-list-item>

                    <v-list-item to="/realtors-table">
                        <v-list-item-icon>
                            <v-icon>mdi-format-list-bulleted</v-icon>
                        </v-list-item-icon>
                        <v-list-item-title>Список риелторов</v-list-item-title>
                    </v-list-item>

                    <v-list-item to="/create">
                        <v-list-item-icon>
                            <v-icon>mdi-account-plus</v-icon>
                        </v-list-item-icon>
                        <v-list-item-title>Новый риелтор</v-list-item-title>
                    </v-list-item>

                </v-list-item-group>
            </v-list>
        </v-navigation-drawer>
    </v-card>
</template>

<script>
    export default {
        data: () => ({
            drawer: false,
            search: '',
            menuItems: [
                {
                    text: '111',
                    value: 'val1',
                    disabled: false,
                    header: 'Новый риэлтор'
                },
                {
                    text: '222',
                    value: 'val2',
                    disabled: false,
                    header: 'Список риэлторов'
                },
            ],
        })
    }
</script>

<style scoped>

    .searchButton {
        margin-left: 10px;
    }

</style>






