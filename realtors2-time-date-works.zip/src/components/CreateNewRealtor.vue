<template v-if="visible">
    <div>
    <v-card
            class="overflow-hidden"
            color="purple lighten-1"
            dark
    >
        <v-toolbar
                flat
                color="purple"
        >
            <v-icon>mdi-account</v-icon>
            <v-toolbar-title class="font-weight-light">Добавить нового риэлтора</v-toolbar-title>
            <v-spacer></v-spacer>
        </v-toolbar>
        <v-card-text>
            <v-text-field
                    color="white"
                    label="Имя"
            ></v-text-field>
            <v-text-field
                    color="white"
                    label="Фамилия"
            ></v-text-field>
            <v-autocomplete
                    :disabled="false"
                    :items="states"
                    :filter="customFilter"
                    color="white"
                    item-text="name"
                    label="Подразделение"
            ></v-autocomplete>
        </v-card-text>
        <v-divider></v-divider>
        <v-card-actions>
            <v-spacer></v-spacer>
            <v-btn
                    :disabled="false"
                    color="success"
                    @click="cancel"
                    v-on:click="visible=!visible"
            >
                Cancel
            </v-btn>
            <v-btn
                    :disabled="false"
                    color="success"
                    @click="save"
                    v-on:click="visible=!visible"
            >
                Save
            </v-btn>
        </v-card-actions>
        <v-snackbar
                v-model="hasSaved"
                :timeout="2000"
                absolute
                bottom
                left
        >
            Готово!
        </v-snackbar>
    </v-card>
        <Button/>
    </div>
</template>

<script>
    import Button from './features/Button'
    export default {
        name: "CreateNewRealtor.vue",
        components: {Button},
        data () {
            return {
                hasSaved: false,
                model: null,
                visible: false,
                states: [
                    { name: 'Ипотека' },
                    { name: 'Дома' },
                    { name: 'Квартиры'},
                    { name: 'Коммерческая недвижимость' },
                    { name: 'Земельные участки' },
                ],
            }
        },

        methods: {
            customFilter (item, queryText, itemText) {
                const textOne = item.name.toLowerCase();
                const textTwo = item.abbr.toLowerCase();
                const searchText = queryText.toLowerCase();

                return textOne.indexOf(searchText) > -1 ||
                    textTwo.indexOf(searchText) > -1
            },
            save () {
                this.hasSaved = true;
            },
        },
    }
</script>

<style scoped>

</style>
