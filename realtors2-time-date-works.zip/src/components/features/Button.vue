<template>
    <v-row align="center" class="container">

        <v-col class="text-center">
            <div class="my-2" >
                <v-btn color="primary" to="/">Главная</v-btn>
            </div>
        </v-col>
    </v-row>
</template>

<script>
    export default {
        name: "Button.vue"
    }
</script>

<style scoped>
    .container {
        /*display: flex;*/
        /*justify-content: center;*/
    }
</style>
